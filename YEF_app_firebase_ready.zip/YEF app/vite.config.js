import react from '@vitejs/plugin-react'
import { defineConfig } from 'vite'

// Vite config for local dev (Firebase replaces Base44)
export default defineConfig({
  plugins: [react()],
});
